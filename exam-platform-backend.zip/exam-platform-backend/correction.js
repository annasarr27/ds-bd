const ollama = require("ollama").default;

async function corrigerCopie(texteCopie, texteCorrigeType) {
    const prompt = `
   Tu es un correcteur d'examen expert. Ton objectif est d'évaluer la copie d'un étudiant en la comparant à un corrigé type.

    - Lis attentivement la copie de l'étudiant et le corrigé type.
    - Attribue une note sur 20 en fonction de la pertinence des réponses.
    - Justifie ta notation en expliquant les points forts et les erreurs.

    Copie de l'étudiant :
    ${texteCopie}

    Corrigé type :
    ${texteCorrigeType}

    Réponds sous ce format :
    - Note : XX/20
    - Explication : "..."
    `;

    try {
        console.log("🟢 Envoi de la requête à Ollama...");

        const response = await ollama.generate({
            model: "deepseek-coder",
            prompt: prompt
        });

        console.log("✅ Réponse reçue :", response);
        return response.response;
    } catch (error) {
        console.error("❌ Erreur Ollama :", error);
        return "Erreur lors de la correction automatique.";
    }
}

module.exports = { corrigerCopie };