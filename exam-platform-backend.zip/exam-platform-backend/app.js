const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { sequelize, User, Exam, Submission } = require("./models");
const routes = require("./routes"); // Import des routes
const { corrigerCopie } = require("./correction"); // Import de la correction IA
const { detecterPlagiat } = require("./plagiat"); // 💡 Vérifie bien cette ligne !

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Test de la connexion à la base de données
sequelize.authenticate()
    .then(() => console.log("✅ Connexion à la base de données réussie."))
    .catch(err => console.error("❌ Impossible de se connecter à la base de données :", err));

// Synchronisation des modèles avec la base de données
sequelize.sync({ force: false }) // force: true efface et recrée les tables (à utiliser avec précaution)
    .then(() => console.log("✅ Modèles synchronisés avec la base de données."))
    .catch(err => console.error("❌ Erreur de synchronisation des modèles :", err));

// Utilisation des routes
app.use(routes); // Utilise les routes définies dans routes/index.js

// Route de bienvenue
app.get("/", (req, res) => {
    res.send("Bienvenue sur la plateforme de gestion d'examens !");
});

// Route de connexion utilisateur
app.post("/login", (req, res) => {
    const { email, mot_de_passe } = req.body;
    if (!email || !mot_de_passe) {
        return res.status(400).json({ error: "Email et mot de passe requis." });
    }
    // Logique de connexion...
});

// ✅ Route pour la correction automatique IA
app.post("/corriger", async(req, res) => {
    const { texteCopie, texteCorrigeType } = req.body;

    try {
        const resultat = await corrigerCopie(texteCopie, texteCorrigeType);
        res.json({ correction: resultat });
    } catch (error) {
        console.error("❌ Erreur lors de la correction :", error);
        res.status(500).json({ error: "Erreur de l'IA" });
    }
});

// Route pour la détection de plagiat
app.post("/plagiat", (req, res) => {
    const { texteCopie, autresCopies } = req.body;

    if (!texteCopie || !autresCopies || autresCopies.length === 0) {
        return res.status(400).json({ error: "Veuillez fournir un texte à analyser et une liste de copies." });
    }

    console.log("📩 Requête reçue pour détection de plagiat.");
    const resultat = detecterPlagiat(texteCopie, autresCopies);

    console.log("✅ Résultat :", resultat);
    res.json({ resultat });
});

// Démarrage du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Serveur démarré sur le port ${PORT}`);
});