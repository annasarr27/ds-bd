// routes/submissionRoutes.js
const express = require('express');
const router = express.Router();
const SubmissionController = require('../controllers/SubmissionController');
const { authenticate } = require('../middleware/authMiddleware');

// Routes pour les soumissions
router.post('/submissions', authenticate, SubmissionController.createSubmission); // Protégée
router.get('/submissions', authenticate, SubmissionController.getAllSubmissions); // Protégée
router.get('/submissions/:id', authenticate, SubmissionController.getSubmissionById); // Protégée
router.put('/submissions/:id', authenticate, SubmissionController.updateSubmission); // Protégée
router.delete('/submissions/:id', authenticate, SubmissionController.deleteSubmission); // Protégée

module.exports = router;