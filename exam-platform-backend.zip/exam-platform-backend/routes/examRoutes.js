// routes/examRoutes.js
const express = require('express');
const router = express.Router();
const ExamController = require('../controllers/ExamController');
const { authenticate, isEnseignant } = require('../middleware/authMiddleware');

// Routes pour les examens
router.post('/exams', authenticate, isEnseignant, ExamController.createExam); // Protégée
router.get('/exams', ExamController.getAllExams); // Publique
router.get('/exams/:id', ExamController.getExamById); // Publique
router.put('/exams/:id', authenticate, isEnseignant, ExamController.updateExam); // Protégée
router.delete('/exams/:id', authenticate, isEnseignant, ExamController.deleteExam); // Protégée

module.exports = router;