// routes/index.js
const express = require('express');
const router = express.Router();

// Import des routes
const userRoutes = require('./userRoutes');
const examRoutes = require('./examRoutes');
const submissionRoutes = require('./submissionRoutes');
const chatbotLogRoutes = require('./chatbotLogRoutes');
const plagiarismReportRoutes = require('./plagiarismReportRoutes');

// Utilisation des routes
router.use('/api', userRoutes);
router.use('/api', examRoutes);
router.use('/api', submissionRoutes);
router.use('/api', chatbotLogRoutes);
router.use('/api', plagiarismReportRoutes);

module.exports = router;