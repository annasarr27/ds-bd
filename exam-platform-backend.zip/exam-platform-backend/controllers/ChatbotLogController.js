// controllers/ChatbotLogController.js
const { ChatbotLog, User } = require('../models');

// Créer un log de chatbot
exports.createChatbotLog = async (req, res) => {
  try {
    const { question, reponse } = req.body;
    const etudiant_id = req.user.id; // Récupérer l'ID de l'utilisateur authentifié

    const chatbotLog = await ChatbotLog.create({ etudiant_id, question, reponse });
    res.status(201).json(chatbotLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// Obtenir tous les logs de chatbot
exports.getAllChatbotLogs = async (req, res) => {
  try {
    const chatbotLogs = await ChatbotLog.findAll({ include: User });
    res.status(200).json(chatbotLogs);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Obtenir un log de chatbot par son ID
exports.getChatbotLogById = async (req, res) => {
  try {
    const chatbotLog = await ChatbotLog.findByPk(req.params.id, { include: User });
    if (!chatbotLog) {
      return res.status(404).json({ error: 'Log de chatbot non trouvé' });
    }
    res.status(200).json(chatbotLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Mettre à jour un log de chatbot
exports.updateChatbotLog = async (req, res) => {
  try {
    const { etudiant_id, question, reponse } = req.body;
    const [updated] = await ChatbotLog.update(
      { etudiant_id, question, reponse },
      { where: { id: req.params.id } }
    );
    if (updated) {
      const updatedChatbotLog = await ChatbotLog.findByPk(req.params.id);
      res.status(200).json(updatedChatbotLog);
    } else {
      res.status(404).json({ error: 'Log de chatbot non trouvé' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Supprimer un log de chatbot
exports.deleteChatbotLog = async (req, res) => {
  try {
    const deleted = await ChatbotLog.destroy({ where: { id: req.params.id } });
    if (deleted) {
      res.status(204).send();
    } else {
      res.status(404).json({ error: 'Log de chatbot non trouvé' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};