// controllers/ExamController.js
const { Exam, User } = require('../models');

// Créer un examen
exports.createExam = async (req, res) => {
  try {
    const { titre, description, fichier_exam } = req.body;
    const enseignant_id = req.user.id; // Récupérer l'ID de l'utilisateur authentifié

    const exam = await Exam.create({ titre, description, enseignant_id, fichier_exam });
    res.status(201).json(exam);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Obtenir tous les examens
exports.getAllExams = async (req, res) => {
  try {
    const exams = await Exam.findAll({ include: User });
    res.status(200).json(exams);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Obtenir un examen par son ID
exports.getExamById = async (req, res) => {
  try {
    const exam = await Exam.findByPk(req.params.id, { include: User });
    if (!exam) {
      return res.status(404).json({ error: 'Examen non trouvé' });
    }
    res.status(200).json(exam);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Mettre à jour un examen
exports.updateExam = async (req, res) => {
  try {
    const { titre, description, fichier_exam } = req.body;
    const exam = await Exam.findByPk(req.params.id);

    if (!exam) {
      return res.status(404).json({ error: 'Examen non trouvé' });
    }
    // Vérifier que l'utilisateur authentifié est l'enseignant qui a créé l'examen
    if (exam.enseignant_id !== req.user.id) {
      return res.status(403).json({ error: 'Accès refusé. Vous n\'êtes pas l\'enseignant de cet examen.' });
    }

    const [updated] = await Exam.update(
      { titre, description, fichier_exam },
      { where: { id: req.params.id } }
    );

    if (updated) {
      const updatedExam = await Exam.findByPk(req.params.id);
      res.status(200).json(updatedExam);
    } else {
      res.status(404).json({ error: 'Examen non trouvé' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Supprimer un examen
exports.deleteExam = async (req, res) => {
  try {
    const exam = await Exam.findByPk(req.params.id);

    if (!exam) {
      return res.status(404).json({ error: 'Examen non trouvé' });
    }
      // Vérifiez que l'utilisateur authentifié est bien l'enseignant qui a créé l'examen avant de le supprimer
    // Vérifier que l'utilisateur authentifié est l'enseignant qui a créé l'examen
    if (exam.enseignant_id !== req.user.id) {
      return res.status(403).json({ error: 'Accès refusé. Vous n\'êtes pas l\'enseignant de cet examen.' });
    }

    const deleted = await Exam.destroy({ where: { id: req.params.id } });
    if (deleted) {
      res.status(204).send();
    } else {
      res.status(404).json({ error: 'Examen non trouvé' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};